package com.example.breathalyzer;

public class Result {

}
