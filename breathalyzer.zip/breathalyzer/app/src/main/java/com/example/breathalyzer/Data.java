package com.example.breathalyzer;

public class Data {
    // string variable for
    // storing employee name.
    private float level_ppm;

    // string variable for storing
    // employee contact number
    private float level;

    // string variable for storing
    // employee address.
    private int year;

    private int month;

    private int day;

    // an empty constructor is
    // required when using
    // Firebase Realtime Database.
    public Data() {

    }

    // created getter and setter methods
    // for all our variables.
    public float getlevel_ppm() {
        return level_ppm;
    }

    public void setLevel_ppm(float level) {
        this.level_ppm = level;
    }

    public float getlevel() {
        return level;
    }

    public void setLevel(float level1) {
        this.level = level1;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int Nyear) {
        this.year = Nyear;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int Nmonth) {
        this.month = Nmonth;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int Nday) {
        this.day = Nday;
    }
}
